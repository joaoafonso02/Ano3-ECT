int foo(int bar)
{
	return 3;
}

int main(int argc, char** argv)
{
	foo(argc);

	return 0;
}
