%{
    O espaço de amostragem é constituido por 3 notas
    
    x = {5, 50, 100}
    
    px(xi) = [0.9 0.09 0.1]
%}