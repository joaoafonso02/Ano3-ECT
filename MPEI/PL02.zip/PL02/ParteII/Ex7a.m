n = 1;
p = 15;
k = 0;

% Poisson
fprintf("Distribuição Poisson: %d\n", poisson_dist(n,k,p));