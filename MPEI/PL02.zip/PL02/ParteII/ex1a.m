% E[x] -> valor medio(ou media, ou valor esperado)
clear all;
% valores teoricos
p = ones(1,6) / 6

bar(p), xlabel('x'), ylabel('y(x)')

