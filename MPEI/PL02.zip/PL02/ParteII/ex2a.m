%{
    90 notas de 5 Euros, 
    9 notas de 50,
    1 de 100

    O espaço de amostragem é constituido por 100 elementos(notas),
cada um constituido por 1 nota acima referida
    
    PROBABILIDADES DOS ACONTECIMENTOS ELEMENTARES
    p(5) -> probabilidade de sair nota de 5e
    casos favoraveis: 90
    casos totais: 100
    p(5) = 90/100 = 0.9
    
    p(50) -> probabilidade de sair nota de 50e
    casos favoraveis: 9
    casos totais: 100
    p(50) = 9/100 = 0.09

    p(100) -> probabilidade de sair nota de 100
    casos favoraveis: 1
    casos totais: 100
    p(100) = 1/100 = 0.01
%}

