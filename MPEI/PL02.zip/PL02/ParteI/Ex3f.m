%i) the probablity of obtaining at least 2 tails

Pi = nchoosek(4,2)/8 + nchoosek(4,3)/8 + nchoosek(4,4)/8