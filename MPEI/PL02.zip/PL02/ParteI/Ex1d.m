fam = rand(2, N);
rapazes = fam < 0.5;

% 1º filho
rapazes(1,:)

% 2º filho
rapazes(2,:)